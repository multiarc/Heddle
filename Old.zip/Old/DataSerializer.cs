﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Templates.Core.Serialization
{
    /// <summary>
    /// Abstract snippet class for all serializiable data for templating engine
    /// </summary>
    public static class DataSerializer
    {
        //TODO: парсинг шаблона, создание соответствий мембера типа и названия в шаблоне, прямые геттеры из подшаблона. Кэширование подшаблонов всех уровней.
        /// <summary>
        /// Serializes object himself, adds all properties wich not market as non serialized by PatternNonSerializedAttribute
        /// </summary>
        /// <returns>Dictinary as first level of object tree, each object as value can be another Dictionary</returns>
        /// <see cref="NonSerializedAttribute"/>
        public static Dictionary<string, object> Serialize(object data)
        {
            if (data == null) throw new ArgumentNullException("data");

            var result = new Dictionary<string, object>();
            Type type = data.GetType();
            IEnumerable<PropertyInfo> properties = type.GetProperties()
                .Where(p =>
                       p.CanRead &&
                       (((p.DeclaringType ?? typeof(object)).Attributes & TypeAttributes.Public) > 0 ||
                        ((p.DeclaringType ?? typeof(object)).Attributes & TypeAttributes.BeforeFieldInit) > 0) &&
                       !p.GetCustomAttributes(false)
                            .Any(a => a is NonSerializedAttribute)
                );

            foreach (PropertyInfo property in properties)
            {
                var attributes = new AttributeSet(property.GetCustomAttributes(false));
                string propertyName = property.Name;
                var options = attributes.GetAttribute<OptionsAttribute>();
                var additional = attributes.GetAttribute<AdditionalAttribute>();
                string patternName = null, additionalPatternName = null;
                if (options != null)
                {
                    if (!string.IsNullOrEmpty(options.FieldName))
                    {
                        propertyName = options.FieldName;
                    }
                    patternName = options.PatternName;
                }
                if (additional != null)
                {
                    additionalPatternName = additional.PatternName;
                }
                ISerializing pattern = PatternFactory.Create(property.PropertyType, additionalPatternName ?? patternName);
                result.Add(propertyName, additionalPatternName == null ? 
                    pattern.SerializeData(property.GetValue(data, null)) : 
                    pattern.SerializeAdditionalData(property.GetValue(data, null)));
            }
            return result;
        }
    }
}