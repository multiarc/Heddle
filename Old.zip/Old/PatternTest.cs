﻿using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Templates;
using Templates.Core;
using TestExampleProject.TestData;

namespace TestExampleProject {
    /// <summary>
    ///This is a test class for PatternTest and is intended
    ///to contain all PatternTest Unit Tests
    ///</summary>
    [TestClass]
    public class PatternTest {
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get;
            set;
        }

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        /// <summary>
        ///A test for GenerateString
        ///</summary>
        [TestMethod]
        public void GenerateStringTest ()
        {
            TextWriter templateGeneratedResult = new StreamWriter(@"D:\Work\Templater\TestExampleProject\TestTemplate\generated.html", false);
            var target = new Pattern
                (typeof (TestDataStructure), new TemplateOptions
                                             {
                                                 PatternName = "template",
                                                 DefaultFileExtension = ".html",
                                                 RootPath = @"D:\Work\Templater\TestExampleProject\TestTemplate"
                                             });
            templateGeneratedResult.Write((char[]) target.ProcessData(DataFiller.FillData()));
            templateGeneratedResult.Close();
        }
    }
}