﻿namespace Templates.Core.Serialization
{
    /// <summary>
    /// Abstract class implements default behavior of serialization for simple or compatibility with pattern types
    /// </summary>
    public abstract class Serializing : ISerializing
    {
        #region ISerializing Members

        /// <summary>
        /// Serializes data into internal representation of pattern
        /// </summary>
        /// <param name="data">Object to be serialized by pattern</param>
        /// <returns>Does nothing with input object just returns it</returns>
        public virtual object SerializeData(object data)
        {
            return data;
        }

        public virtual object SerializeAdditionalData(object data)
        {
            return data;
        }

        #endregion
    }
}