﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Templates.Core;

namespace TestExampleProject {
    /// <summary>
    ///This is a test class for FastStringTest and is intended
    ///to contain all FastStringTest Unit Tests
    ///</summary>
    [TestClass]
    public class FastStringTest {
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get;
            set;
        }

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        /// <summary>
        ///A test for Equals
        ///</summary>
        [TestMethod]
        public void EqualsTest ()
        {
            FastString string1 = "flksajdkalsdjfklsd";
            FastString string2 = "flksajdkalsdjfklsd";
            Assert.IsTrue(FastString.Equals(string1, string2));
            string1 = "";
            Assert.IsFalse(FastString.Equals(string1, string2));
            string2 = "";
            Assert.IsTrue(FastString.Equals(string1, string2));
            string1 = null;
            Assert.IsFalse(FastString.Equals(string1, string2));
        }

        /// <summary>
        ///A test for GetHashCode
        ///</summary>
        [TestMethod]
        public void GetHashCodeTest ()
        {
            //FastString target = "jfh9hj8943jf";
            //Assert.Fail(target.GetHashCode().ToString());
        }

        /// <summary>
        ///A test for IsEmptyMeaning
        ///</summary>
        [TestMethod]
        public void IsEmptyMeaningTest ()
        {
            FastString value = "                        \n\r   \r\r\r\r\n\n\n\n \n";
            Assert.IsTrue(FastString.IsNullOrWhiteSpace(value));
            value = "    a       ";
            Assert.IsFalse(FastString.IsNullOrWhiteSpace(value));
        }

        /// <summary>
        ///A test for IsNullOrEmpty
        ///</summary>
        [TestMethod]
        public void IsNullOrEmptyTest ()
        {
            FastString value = null;
            Assert.IsTrue(FastString.IsNullOrEmpty(value));
            Assert.IsTrue(FastString.IsNullOrEmpty(""));
            Assert.IsTrue(FastString.IsNullOrEmpty(new FastString()));
        }

        /// <summary>
        ///A test for Replace
        ///</summary>
        [TestMethod]
        public void ReplaceTest ()
        {
            FastString value = "aabbbdddcdcdcПРИВЕТdllkacdscПРИВЕТ";
            FastString toFind = "ПРИВЕТ";
            FastString toReplace = "__";
            FastString expected = "aabbbdddcdcdc__dllkacdsc__";
            FastString actual = value.Replace(toFind, toReplace);
            Assert.AreEqual(expected, actual);
            value = "aabbbddПРИВЕТdcdcdПРИВЕТcdllkacdscdПРИВЕТ";
            toFind = "ddПРИВЕТ";
            toReplace = "__";
            expected = "aabbb__dcdcdПРИВЕТcdllkacdscdПРИВЕТ";
            actual = value.Replace(toFind, toReplace);
            Assert.AreEqual(expected, actual);
            value = "cdbbbdddcПРИВЕТdcdcdllПРИВЕТkacdscd";
            toFind = "lПРИВЕТ";
            toReplace = "__";
            expected = "cdbbbdddcПРИВЕТdcdcdl__kacdscd";
            actual = value.Replace(toFind, toReplace);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for ToString
        ///</summary>
        [TestMethod]
        public void ToStringTest ()
        {
            var target = new FastString("dkashjdfklasjfdsaklfjakslf");
            string expected = "dkashjdfklasjfdsaklfjakslf";
            string actual;
            actual = target.ToString();
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for Trim
        ///</summary>
        [TestMethod]
        public void TrimTest ()
        {
            var target = new FastString("dkjasdkljasldjkasljdljasklj");
            FastString expected = "dkjasdkljasldjkasljdljasklj";
            FastString actual;
            actual = target.Trim();
            Assert.AreEqual(expected, actual);
            target = " dkjasdkljasldjkasljdljasklj";
            actual = target.Trim();
            Assert.AreEqual(expected, actual);
            target = " dkjasdkljasldjkasljdljasklj     ";
            actual = target.Trim();
            Assert.AreEqual(expected, actual);
            target = "dkjasdkljasldjkasljdljasklj     ";
            actual = target.Trim();
            Assert.AreEqual(expected, actual);
            target = "     dkjasdkljasldjkasljdljasklj     ";
            actual = target.Trim();
            Assert.AreEqual(expected, actual);
            target = "     dkjasdkljasldjkasljdljasklj";
            actual = target.Trim();
            Assert.AreEqual(expected, actual);
        }
    }
}