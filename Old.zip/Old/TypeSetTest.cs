﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Templates.Attributes;
using Templates.Core;

namespace TestExampleProject {
    /// <summary>
    ///This is a test class for TypeSetTest and is intended
    ///to contain all TypeSetTest Unit Tests
    ///</summary>
    [TestClass]
    public class TypeSetTest {
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get;
            set;
        }

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        /// <summary>
        ///A test for IsType
        ///</summary>
        [TestMethod]
        public void IsTypeTest ()
        {
            var target = new ReflectionHelper(typeof (object));
            Assert.IsTrue(target.IsType(typeof (object)));
            Assert.IsTrue(target.IsType(typeof (DeploymentItemAttribute)));
            Assert.IsTrue(target.IsType(typeof (Test)));
            target = new ReflectionHelper(typeof (Attribute));
            Assert.IsTrue(target.IsType(typeof (NameAttribute)));
            Assert.IsTrue(target.IsType(typeof (Attribute)));
            Assert.IsFalse(target.IsType(typeof (object)));
            Assert.IsFalse(target.IsType(typeof (IEquatable<>)));
        }

        /// <summary>
        ///A test for IsObject
        ///</summary>
        [TestMethod]
        public void IsObjectTest ()
        {
            var target = new ReflectionHelper(typeof (object));
            Assert.IsTrue(target.IsObject());
            target = new ReflectionHelper(typeof (DeploymentItemAttribute));
            Assert.IsFalse(target.IsObject());
            target = new ReflectionHelper(typeof (IEquatable<>));
            Assert.IsFalse(target.IsObject());
        }

        /// <summary>
        ///A test for IsInterface
        ///</summary>
        [TestMethod]
        public void IsInterfaceTest ()
        {
            var target = new ReflectionHelper(typeof (IEquatable<>));
            Assert.IsTrue(target.IsInterface());
            target = new ReflectionHelper(typeof (DeploymentItemAttribute));
            Assert.IsFalse(target.IsInterface());
        }

        /// <summary>
        ///A test for IsClass
        ///</summary>
        [TestMethod]
        public void IsClassTest ()
        {
            var target = new ReflectionHelper(typeof (IEquatable<>));
            Assert.IsFalse(target.IsClass());
            target = new ReflectionHelper(typeof (DeploymentItemAttribute));
            Assert.IsTrue(target.IsClass());
            target = new ReflectionHelper(typeof (TestContext));
            Assert.IsTrue(target.IsClass());
        }

        #region Nested type: Test

        public class Test {
        }

        #endregion
    }
}