﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Templates.Core;

namespace TestExampleProject {
    /// <summary>
    ///This is a test class for FastStringBuilderTest and is intended
    ///to contain all FastStringBuilderTest Unit Tests
    ///</summary>
    [TestClass]
    public class FastStringBuilderTest {
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get;
            set;
        }

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        /// <summary>
        ///A test for Append
        ///</summary>
        [TestMethod]
        public void AppendTest ()
        {
            var target = new FastStringBuilder();
            FastString value = "10000002";
            FastString value2 = "10000001";
            target.Append(value);
            target.Append(value);
            target.Append(value);
            target.Append(value);
            target.Append(value2);
            Assert.AreEqual(target.ToFastString(), new FastString("1000000210000002100000021000000210000001"));
            target.Clear();
            target.Append("1231");
            target.Append("4124");
            target.Append("123gdf");
            target.Append("15151");
            target.Append("32423431");
            Assert.AreEqual(target.ToFastString(), "12314124123gdf1515132423431");
            target.Clear();
            target.Append("1231");
            target.Append("4124");
            target.Append("123gdf");
            target.Append("15151");
            target.Append("32423431");
            target.Clear();
            Assert.AreEqual(target.ToFastString(), "");
        }

        /// <summary>
        ///A test for Clear
        ///</summary>
        [TestMethod]
        public void ClearTest ()
        {
            var target = new FastStringBuilder(); // TODO: Initialize to an appropriate value
            target.Clear();
            Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for ToString
        ///</summary>
        [TestMethod]
        public void ToStringTest ()
        {
            var target = new FastStringBuilder(); // TODO: Initialize to an appropriate value
            string expected = string.Empty; // TODO: Initialize to an appropriate value
            string actual;
            actual = target.ToString();
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for op_Implicit
        ///</summary>
        [TestMethod]
        public void op_ImplicitTest ()
        {
            FastStringBuilder builder = null; // TODO: Initialize to an appropriate value
            FastString expected = null; // TODO: Initialize to an appropriate value
            FastString actual;
            //actual = builder;
            Assert.AreEqual(expected, null);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Capacity
        ///</summary>
        [TestMethod]
        public void CapacityTest ()
        {
            var target = new FastStringBuilder(); // TODO: Initialize to an appropriate value
            int expected = 0; // TODO: Initialize to an appropriate value
            int actual;

            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for Length
        ///</summary>
        [TestMethod]
        public void LengthTest ()
        {
            var target = new FastStringBuilder(); // TODO: Initialize to an appropriate value
            int actual;
            actual = target.Length;
            Assert.Inconclusive("Verify the correctness of this test method.");
        }
    }
}