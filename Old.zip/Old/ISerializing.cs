﻿namespace Templates.Core.Serialization
{
    /// <summary>
    /// Interface for pattern serialization implementation (Pattern Serialize input data object by himself)
    /// </summary>
    public interface ISerializing
    {
        /// <summary>
        /// Serializes data into internal representation of pattern
        /// </summary>
        /// <param name="data">Data to serialize</param>
        /// <returns>Returns serialized object data used in pattern later</returns>
        object SerializeData(object data);

        /// <summary>
        /// Serializes additional portion of data into internal representation of pattern
        /// </summary>
        /// <param name="data">Data to serialize</param>
        /// <returns>Returns serialized object data used in pattern later</returns>
        object SerializeAdditionalData(object data);
    }
}